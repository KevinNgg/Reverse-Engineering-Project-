function myFunction (){
  document.getElementById("pageone").innerHTML = "insert next page";
}